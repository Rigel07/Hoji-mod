package com.hoji;

import com.hoji.entity.HojiEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HojiMod.MODID);

    public static final RegistryObject<EntityType<HojiEntity>> HOJI = ENTITY_TYPES.register("hoji",
            () -> EntityType.Builder.of(HojiEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.55F)
                    .clientTrackingRange(10)
                    .build(new ResourceLocation(HojiMod.MODID, "hoji").toString()));
}
