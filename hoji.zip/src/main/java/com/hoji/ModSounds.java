package com.hoji;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, HojiMod.MODID);

    public static final RegistryObject<SoundEvent> HOJI_AMBIENT = register("hoji_ambient");
    public static final RegistryObject<SoundEvent> HOJI_HURT = register("hoji_hurt");
    public static final RegistryObject<SoundEvent> HOJI_DEATH = register("hoji_death");
    public static final RegistryObject<SoundEvent> HOJI_HAPPY = register("hoji_happy");
    public static final RegistryObject<SoundEvent> HOJI_EAT = register("hoji_eat");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(HojiMod.MODID, name)));
    }
}
