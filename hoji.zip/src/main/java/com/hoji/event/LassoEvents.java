package com.hoji.event;

import com.hoji.HojiMod;
import com.hoji.item.MagicLassoItem;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Captura con el lazo mágico. Se hace con un evento de prioridad máxima para que funcione
 * con cualquier mob (aldeanos, mascotas, mobs de otros mods...) sin que su propia interacción lo impida.
 */
@Mod.EventBusSubscriber(modid = HojiMod.MODID)
public class LassoEvents {

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        ItemStack stack = event.getItemStack();
        if (!(stack.getItem() instanceof MagicLassoItem) || MagicLassoItem.hasCaptured(stack)) {
            return;
        }
        if (!(event.getTarget() instanceof LivingEntity target) || target instanceof Player) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getLevel().isClientSide) {
            return;
        }
        MagicLassoItem.capture(stack, event.getEntity(), target);
    }
}
